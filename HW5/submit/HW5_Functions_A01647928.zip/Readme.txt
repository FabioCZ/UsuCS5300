Readme:
HW5 CS5300 - Functions 
by Fabio Gottlicher A01647928

Project structure based largely on: https://www.gnu.org/software/bison/manual/bison.html#A-Complete-C_002b_002b-Example

Compiled using:
CMake 2.8.12.2
G++ 4.8.4 
Flex 2.5.35
bison (GNU Bison) 3.0.2
Boost libraries (v1.54.0.1ubuntu1) 

To run:
$cmake .
$make
$./f_cpsl -o outFile.asm inFile.cpsl

Help:
$./f_cpsl -h
Fabio Gottlicher's CPSL Compiler
Created for USU CS5300 - Compiler Construction, Spring 2016
USAGE: f_cpsl [OPTIONS] inputFileName
OPTIONS:
-p                Parser Tracing
-s                Scanner Tracing
-o outFileName    (optional) Output file name (default is out.asm)

Tested on Ubuntu 14.04 x64
