CS5300 HW1
Keano Gottlicher A01647928

Compiled with:
Ubuntu 14.04 x64
g++-4.8 (v4.8.4) (needs to be set in path as "g++-4.8", or edit CMakeLists.txt to specify your g++ alias)
flex (v2.5.35)
CMake (v2.8.12.2)
Boost libraries (v1.54.0.1ubuntu1) (to install on Ubuntu: $sudo apt-get install libboost-all-dev)

Instructions:
Generates output executable named CS5300HW1
analyzes output from std input.
example use:
#testFile.cpsl has CSPL code to be tested
$cat testFile.cpsl | ./CS5300HW1
